import matplotlib
import matplotlib.pyplot as plt 
import numpy as np 
from tqdm import tqdm
import glob
import os
import json
import cv2
import pandas as pd

from utils.gt_utils import compute_box_3d,read_label,draw_gt_boxes3d,compute_o2w,compute_o2w_from_c2w
from utils.camera_utils import inverse_rigid_trans
from utils.imu_utils import convertOxtsToPose

def draw_projected_box3d(image, qs, color=(0, 255, 0), thickness=1):
    """ Draw 3d bounding box in image
        qs: (8,3) array of vertices for the 3d box in following order:
            1 -------- 0
           /|         /|
          2 -------- 3 .
          | |        | |
          . 5 -------- 4
          |/         |/
          6 -------- 7
    """
    qs = qs.astype(np.int32)
    for k in range(0, 4):
        # Ref: http://docs.enthought.com/mayavi/mayavi/auto/mlab_helper_functions.html
        i, j = k, (k + 1) % 4
        # use LINE_AA for opencv3
        # cv2.line(image, (qs[i,0],qs[i,1]), (qs[j,0],qs[j,1]), color, thickness, cv2.CV_AA)
        cv2.line(image, (qs[i, 0], qs[i, 1]), (qs[j, 0], qs[j, 1]), color, thickness)
        i, j = k + 4, (k + 1) % 4 + 4
        cv2.line(image, (qs[i, 0], qs[i, 1]), (qs[j, 0], qs[j, 1]), color, thickness)

        i, j = k, k + 4
        cv2.line(image, (qs[i, 0], qs[i, 1]), (qs[j, 0], qs[j, 1]), color, thickness)
    return image

class Object3d_simple(object):
    """ 3d object label """

    def __init__(self, label_file_line):
        data = label_file_line.split(" ")
        data = data[3:] + [data[2]]
        data[1:] = [float(x) for x in data[1:]]  
        self.type = data[0]
        self.h = data[1]  # box height
        self.w = data[2]  # box width
        self.l = data[3]  # box length (in meters)
        self.t = (data[4], data[5], data[6])  # location (x,y,z) in camera coord.
        self.ry = data[7]  # yaw angle (around Y-axis in camera coordinates) [-pi..pi]
        self.uid = int(data[-1])

# 车辆坐标系下的bev图像
# from zl,相机坐标系,增加相机转车辆步骤;
# from ml,车辆坐标系,无需旋转;

class Object3d_ego(object):
    """ 3d object label """

    def __init__(self, data):
        self.type = 'Ego'  # 'Car', 'Pedestrian', ...
        self.frame = data[0]  
        self.h = data[1]  # box height
        self.w = data[2]  # box width
        self.l = data[3]  # box length (in meters)
        self.ry = data[4]  # yaw angle (around Y-axis in camera coordinates) [-pi..pi]
        self.t = (0,0,0)
        self.confidence = -1
        self.uid = -1

def plotBEV(file,boxes,border,lanes):
    fig = plt.figure(dpi=500,figsize=(5,2))
    axes = plt.gca()
    #fig, axes = plt.subplots(dpi=500)
    axes.set_title('Frame:{}'.format(file))
    axes.set_aspect('equal', adjustable='box')
    axes.set_xlim([border[0]-5, border[1]+5])
    #axes.set_xlim([-2800, -2600])
    axes.set_ylim([border[2]-5, border[3]+5])
    for box,btype,uid in boxes: 
        if btype == 'Ego': 
            clr = 'red'
        elif btype in ["Car","Van"]: 
            clr = 'blue'
        else: 
            clr = 'green'
        rect = matplotlib.patches.Polygon(box[:4,:2], closed=True,zorder=1,fill=False,color=clr)
        axes.add_patch(rect)
        axes.plot(box[4:6,0],box[4:6,1],color='black',linewidth=.5)
        axes.text(np.mean(box[:4,0]),np.mean(box[:4,1])-0.5,str(int(uid)),horizontalalignment='center', fontsize=2.5,fontweight='semibold')
    
    try:
        for lane in lanes:
            locations = np.array(lane['xyz'])
            axes.plot(locations[:,1],-locations[:,0],color = 'green',linewidth=.5)
            #axes.text(locations[-1,1]+1,-locations[-1,0],str(int(lane['lane_id'])),horizontalalignment='center', fontsize=2.5,fontweight='semibold')
    except:
        for lane,lid in lanes:
            axes.plot(lane[:,0],lane[:,1],color = 'green',linewidth=.5)
            #axes.text(lane[-1,0]+1,lane[-1,1],str(int(lid)),horizontalalignment='center', fontsize=2.5,fontweight='semibold')
    return fig

def load_json_file(file_path):
    json_lines = []
    with open(file_path, 'r') as file:
        for line in file:
            # print("line", line)
            try:
                # 尝试逐行解析 JSON 对象
                lane_data = json.loads(line.strip())
                json_lines.append(lane_data)
            except json.JSONDecodeError:
                # 跳过格式错误的行
                continue
    return json_lines

def fov_w(fig_dir,line_label_dir,ex_dir,track_dir,save_dir): 
    #with open(line_label_dir,'r') as f:
        #lane_labels = json.load(f) 
    lane_labels = load_json_file(line_label_dir)
    lane_labels.sort(key = lambda x: x['file_path'].split('/')[-1])
    
    boxes_all = []
    lanes_all = []
    n = len(lane_labels)
    #n = 1
    for i in range(n):
        lines = [line.rstrip() for line in open(track_dir)]
        objects = [Object3d_simple(line) for line in lines if line.split(" ")[0] == str(i)]
        
        boxes = []
        lanes = []
        for lane in lane_labels[i]['lane_lines']: 
            temp = np.array(lane['xyz'])
            #temp[:,0],temp[:,1] = temp[:,1],-temp[:,0]
            temp = np.concatenate((temp,np.ones((temp.shape[0],1))),axis=1)
            cam_height = 1.79 
            #cam_height = 0
            cam_pitch = 0.418/180*np.pi
            v2c = np.array([[1, 0, 0, 0],
         [0, np.cos(np.pi/2+cam_pitch), -np.sin(np.pi/2+cam_pitch), cam_height],
         [0, np.sin(np.pi/2+cam_pitch), np.cos(np.pi/2+cam_pitch),0]])
            v2c = np.concatenate((v2c,np.array([[0,0,0,1]])),axis=0) 

            # 1203 
            #c2v = np.array([[9.99991775e-01, -4.02539017e-03, 4.96265061e-04, 0.00000000e+00],
         #[-4.45399714e-04, 1.26271973e-02, 9.99920175e-01, 0.00000000e+00],
         #[-4.03133528e-03, -9.99912171e-01, 1.26253005e-02, 2.11585277e+00]])
            c2v = np.array([[ 9.99990473e-01,  1.72312796e-03, -4.01059771e-03,  0.00000000e+00],
                 [ 4.01378684e-03, -1.85132558e-03,  9.99990231e-01,  0.00000000e+00],
                 [ 1.71568621e-03, -9.99996802e-01, -1.85822421e-03,  2.11586978e+00],
                 [ 0.00000000e+00,  0.00000000e+00,  0.00000000e+00,  1.00000000e+00]])
            #c2v = np.concatenate((c2v,np.array([[0,0,0,1]])),axis=0)
            v2c = inverse_rigid_trans(c2v)
            v2c[3,3] = 1

            temp = temp @ np.transpose(v2c)
            temp[:,1] = temp[:,1]/2.116*1.79
            #print(temp)
            #quit()
            lanes.append((temp[:,:3],1)) 

        for obj in objects: 
            if obj.type not in ["Ego","Car","Van","Cyclist"]:
                continue
            tf_matrix = np.array([[np.cos(obj.ry),-np.sin(obj.ry),0,obj.t[0]]
                        ,[np.sin(obj.ry),np.cos(obj.ry),0,obj.t[1]]
                        ,[0,0,1,obj.t[2]]])

            l = obj.l
            w = obj.w
            h = obj.h
            x_corners = [l / 2, l / 2, -l / 2, -l / 2
                        ,l / 2, l / 2 + 1.0, 0
                        ,l / 2, l / 2, -l / 2, -l / 2]
            z_corners = [h/2, h/2, h/2, h/2
                            , 0, 0, -h/2
                            , -h/2, -h/2, -h/2, -h/2]
            y_corners = [w / 2, -w / 2, -w / 2, w / 2
                        , 0, 0, 0                
                        , w / 2, -w / 2, -w / 2, w / 2]
            ones = [1,1,1,1,1,1,1,1,1,1,1]
            corners_3d = np.vstack([x_corners, y_corners, z_corners,ones])
            box3d_pts_3d_world = np.dot(tf_matrix[:3,:4],corners_3d).T
            boxes.append((box3d_pts_3d_world[:,:3],obj.type,obj.uid))
        lanes_all.append(lanes) 
        boxes_all.append(boxes)
    
    oxts = pd.read_csv(ex_dir)
    oxts = oxts[['lat','lon','altitude','roll','pitch','azimuth']]
    oxts['azimuth'] = (360-oxts['azimuth'])/360*2*np.pi
    oxts['roll'] = oxts['roll']/360*2*np.pi
    oxts['pitch'] = oxts['pitch']/360*2*np.pi
    oxts = np.array(oxts)
    poses = convertOxtsToPose(oxts)
    c2v = np.array([[1,0,0,0],[0,0,1,0],[0,-1,0,0],[0,0,0,1]])
    c2w = np.zeros((n,4,4))
    for i in range(n): 
        c2w[i] = poses[int(10*(397+i))] @ c2v

    fov_dir = os.path.join(save_dir,'FOV_try_topo2d')
    if not os.path.exists(fov_dir):
        os.mkdir(fov_dir)
    images = glob.glob(os.path.join(fig_dir, '*.jpg'))
    images = sorted(images)
    for i in tqdm(range(n)): 
        img = cv2.imread(images[397+i])

        for box,btype,uid in boxes_all[i]: 
            if btype not in ["Car","Van","Cyclist"]:
                continue
            pts_3d_extend = np.hstack((box[[0,1,2,3,7,8,9,10],:], np.ones((8, 1))))
            w2c = inverse_rigid_trans(c2w[i][:3,:4])
            pts_3d = np.dot(pts_3d_extend,np.transpose(w2c))
            
            pts_3d_extend = np.hstack((pts_3d, np.ones((8, 1))))
            if min(pts_3d_extend[:,2]) < 1e-6: 
                continue
            pts_2d = np.dot(pts_3d, np.transpose(np.array(
                #[[7.215377000000e+02,0.000000000000e+00,6.095593000000e+02,4.485728000000e+01],[0.000000000000e+00,7.215377000000e+02,1.728540000000e+02,2.163791000000e-01],[0.000000000000e+00,0.000000000000e+00,1.000000000000e+00,2.745884000000e-03]]  
                #[[7.215377000000e+02,0.000000000000e+00,6.095593000000e+02,0],[0.000000000000e+00,7.215377000000e+02,1.728540000000e+02,0],[0.000000000000e+00,0.000000000000e+00,1.000000000000e+00,0]]                  
                #[[1252.8131021185304, 0.0, 826.588114781398,0], [0.0, 1252.8131021185304, 469.9846626224581,0], [0.0, 0.0, 1.0,0]]
                [[1918.32,0,1866.3],[0,1920.7,1096.6],[0,0,1]]
            )))
            pts_2d[:, 0] /= pts_2d[:, 2]
            pts_2d[:, 1] /= pts_2d[:, 2]
            
            img = draw_projected_box3d(img, pts_2d, color=(0, 0, 255))
            cv2.putText(img, 'ID:{:03d}'.format(uid), (int(pts_2d[0, 0]),int(pts_2d[0, 1])), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=0.5, color=(255,255,255), thickness=2)
        
        for lane,lid in lanes_all[i]:
            pts_2d = np.dot(lane, np.transpose(np.array(
                #[[7.215377000000e+02,0.000000000000e+00,6.095593000000e+02,4.485728000000e+01],[0.000000000000e+00,7.215377000000e+02,1.728540000000e+02,2.163791000000e-01],[0.000000000000e+00,0.000000000000e+00,1.000000000000e+00,2.745884000000e-03]]  
                #[[7.215377000000e+02,0.000000000000e+00,6.095593000000e+02,0],[0.000000000000e+00,7.215377000000e+02,1.728540000000e+02,0],[0.000000000000e+00,0.000000000000e+00,1.000000000000e+00,0]]                  
                #[[1252.8131021185304, 0.0, 826.588114781398,0], [0.0, 1252.8131021185304, 469.9846626224581,0], [0.0, 0.0, 1.0,0]]
                #[[1266.417203046554, 0.0, 816.2670197447984], [0.0, 1266.417203046554, 491.50706579294757], [0.0, 0.0, 1.0]]
                #[[2081.6967190566124, 0.0,  9.6e+02], [0.0, 2081.6967190566124, 6.4e+02], [0.0, 0.0, 1.0]]
                [[1918.32,0,1866.3],[0,1920.7,1096.6],[0,0,1]]
            )))
            pts_2d[:, 0] /= pts_2d[:, 2]
            pts_2d[:, 1] /= pts_2d[:, 2]
            cv2.polylines(img,[pts_2d[:,:2].astype(np.int32)],isClosed=0,color=(0,255,0),thickness=2)
        
        cv2.imwrite(os.path.join(fov_dir,'{:05d}.png'.format(i)),img)

def bev_w(ex_dir,line_label_dir,save_dir): 
    #with open(line_label_dir,'r') as f:
        #lane_labels = json.load(f) 
    lane_labels = load_json_file(line_label_dir)
    lane_labels.sort(key = lambda x: x['file_path'].split('/')[-1])
    
    boxes_all = []
    lanes_all = []
    n = len(lane_labels)
    #n=1

    oxts = pd.read_csv(ex_dir)
    oxts = oxts[['lat','lon','altitude','roll','pitch','azimuth']]
    oxts['azimuth'] = (360-oxts['azimuth'])/360*2*np.pi
    oxts['roll'] = oxts['roll']/360*2*np.pi
    oxts['pitch'] = oxts['pitch']/360*2*np.pi
    oxts = np.array(oxts)
    poses = convertOxtsToPose(oxts)
    c2v = np.array([[1,0,0,0],[0,0,1,0],[0,-1,0,0],[0,0,0,1]])
    c2w = np.zeros((n,4,4))
    for i in range(n): 
        c2w[i] = poses[int(10*(397+i))] @ c2v

    for i in range(n):
        lines = [line.rstrip() for line in open('./output_post.txt')]
        objects = [Object3d_simple(line) for line in lines if line.split(" ")[0] == str(397+i)]
        
        boxes = []
        lanes = []

        for lane in lane_labels[i]['lane_lines']: 
            temp = np.array(lane['xyz'])
            #temp[:,0],temp[:,1] = temp[:,1],-temp[:,0]
            temp = np.concatenate((temp,np.ones((temp.shape[0],1))),axis=1)
            #c2v = np.array([[9.99991775e-01, -4.02539017e-03, 4.96265061e-04, 0.00000000e+00],
         #[-4.45399714e-04, 1.26271973e-02, 9.99920175e-01, 0.00000000e+00],
         #[-4.03133528e-03, -9.99912171e-01, 1.26253005e-02, 2.11585277e+00]])
            c2v = np.array([[ 9.99990473e-01,  1.72312796e-03, -4.01059771e-03,  0.00000000e+00],
                 [ 4.01378684e-03, -1.85132558e-03,  9.99990231e-01,  0.00000000e+00],
                 [ 1.71568621e-03, -9.99996802e-01, -1.85822421e-03,  2.11586978e+00],
                 [ 0.00000000e+00,  0.00000000e+00,  0.00000000e+00,  1.00000000e+00]])
            #c2v = np.concatenate((c2v,np.array([[0,0,0,1]])),axis=0)
            v2c = inverse_rigid_trans(c2v)
            v2c[3,3] = 1
            temp = temp @ np.transpose(v2c) 
            #0912
            temp[:,1] = temp[:,1]/2.116*1.79
            #### 
            # temp[:,0] = temp[:,0]/temp[:,1]*infos[i]['c2v'][2][3]
            # temp[:,2] = temp[:,2]/temp[:,1]*infos[i]['c2v'][2][3]
            # temp[:,1] = infos[i]['c2v'][2][3]     
            temp = temp @ np.transpose(c2w[i])
            #lanes.append((temp,lane['lane_id'])) 
            lanes.append((temp,-1)) 

        for obj in objects: 
            if obj.type not in ["Ego","Car","Van","Cyclist"]:
                continue
            tf_matrix = np.array([[np.cos(obj.ry),-np.sin(obj.ry),0,obj.t[0]]
                        ,[np.sin(obj.ry),np.cos(obj.ry),0,obj.t[1]]
                        ,[0,0,1,obj.t[2]]])

            l = obj.l
            w = obj.w
            h = obj.h
            x_corners = [l / 2, l / 2, -l / 2, -l / 2
                        ,l / 2, l / 2 + 1.0, 0
                        ,l / 2, l / 2, -l / 2, -l / 2]
            z_corners = [h/2, h/2, h/2, h/2
                            , 0, 0, -h/2
                            , -h/2, -h/2, -h/2, -h/2]
            y_corners = [w / 2, -w / 2, -w / 2, w / 2
                        , 0, 0, 0                
                        , w / 2, -w / 2, -w / 2, w / 2]
            ones = [1,1,1,1,1,1,1,1,1,1,1]
            corners_3d = np.vstack([x_corners, y_corners, z_corners,ones])
            box3d_pts_3d_world = np.dot(tf_matrix[:3,:4],corners_3d).T
            boxes.append((box3d_pts_3d_world[:,:3],obj.type,obj.uid)) 
        lanes_all.append(lanes) 
        boxes_all.append(boxes)
    
    xmin,ymin = np.inf,np.inf 
    xmax,ymax = -np.inf,-np.inf 
    #xmin = np.min([np.min([box[:,0].min() for box,btype,uid in boxes]) for boxes in boxes_all])
    #xmax = np.max([np.max([box[:,0].max() for box,btype,uid in boxes]) for boxes in boxes_all])
    #ymin = np.min([np.min([box[:,1].min() for box,btype,uid in boxes]) for boxes in boxes_all])
    #ymax = np.max([np.max([box[:,1].max() for box,btype,uid in boxes]) for boxes in boxes_all])
    for boxes in boxes_all: 
        for box,btype,uid in boxes:
            xmin = min(xmin,box[:,0].min())
            xmax = max(xmax,box[:,0].max())
            ymin = min(ymin,box[:,1].min())
            ymax = max(ymax,box[:,1].max())
    #xmin = min(xmin,np.min([np.min([lane[:,0].min() for lane,lid in lanes]) for lanes in lanes_all]))
    #xmax = max(xmax,np.max([np.max([lane[:,0].max() for lane,lid in lanes]) for lanes in lanes_all]))
    #ymin = min(ymin,np.min([np.min([lane[:,1].min() for lane,lid in lanes]) for lanes in lanes_all]))
    #ymax = max(ymax,np.max([np.max([lane[:,1].max() for lane,lid in lanes]) for lanes in lanes_all]))
    for lanes in lanes_all: 
        for lane,lid in lanes: 
            xmin = min(xmin,lane[:,0].min())
            xmax = max(xmax,lane[:,0].max())
            ymin = min(ymin,lane[:,1].min())
            ymax = max(ymax,lane[:,1].max())
    #xmax = 2000

    bev_dir = os.path.join(save_dir,'BEV_try_topo2d')
    if not os.path.exists(bev_dir):
        os.mkdir(bev_dir)
    for (idx,boxes) in enumerate(tqdm(boxes_all)):
        fig = plotBEV(idx,boxes,(xmin-20,xmax+20,ymin,ymax),lanes_all[idx])
        save_file = os.path.join(bev_dir,'{:05d}.png'.format(idx))
        fig.savefig(save_file)
        plt.close()

def bev_v(ex_dir,line_label_dir,track_dir,save_dir): 
    #with open(line_label_dir,'r') as f:
        #lane_labels = json.load(f) 
    lane_labels = load_json_file(line_label_dir)
    lane_labels.sort(key = lambda x: x['file_path'].split('/')[-1])
    
    boxes_all = []
    lanes_all = []
    n = len(lane_labels)
    #n=1

    oxts = pd.read_csv(ex_dir)
    oxts = oxts[['lat','lon','altitude','roll','pitch','azimuth']]
    oxts['azimuth'] = (360-oxts['azimuth'])/360*2*np.pi
    oxts['roll'] = oxts['roll']/360*2*np.pi
    oxts['pitch'] = oxts['pitch']/360*2*np.pi
    oxts = np.array(oxts)
    poses = convertOxtsToPose(oxts)
    c2v = np.array([[1,0,0,0],[0,0,1,0],[0,-1,0,0],[0,0,0,1]])
    c2w = np.zeros((n,4,4))
    for i in range(n): 
        c2w[i] = poses[int(10*i)] @ c2v

    for i in range(n):
        lines = [line.rstrip() for line in open(track_dir)]
        objects = [Object3d_simple(line) for line in lines if line.split(" ")[0] == str(i)]
        
        boxes = []
        lanes = []

        for lane in lane_labels[i]['lane_lines']: 
            temp = np.array(lane['xyz'])
            #temp[:,0],temp[:,1] = temp[:,1],-temp[:,0]
            temp = np.concatenate((temp,np.ones((temp.shape[0],1))),axis=1)
            #c2v = np.array([[9.99991775e-01, -4.02539017e-03, 4.96265061e-04, 0.00000000e+00],
         #[-4.45399714e-04, 1.26271973e-02, 9.99920175e-01, 0.00000000e+00],
         #[-4.03133528e-03, -9.99912171e-01, 1.26253005e-02, 2.11585277e+00]])
            c2v = np.array([[ 9.99990473e-01,  1.72312796e-03, -4.01059771e-03,  0.00000000e+00],
                 [ 4.01378684e-03, -1.85132558e-03,  9.99990231e-01,  0.00000000e+00],
                 [ 1.71568621e-03, -9.99996802e-01, -1.85822421e-03,  2.11586978e+00],
                 [ 0.00000000e+00,  0.00000000e+00,  0.00000000e+00,  1.00000000e+00]])
            #c2v = np.concatenate((c2v,np.array([[0,0,0,1]])),axis=0)
            v2c = inverse_rigid_trans(c2v)
            v2c[3,3] = 1
            temp = temp @ np.transpose(v2c) 
            #0912
            temp[:,1] = temp[:,1]/2.116*1.79
            temp = temp @ np.transpose(np.array([[0,0,1,0],[-1,0,0,0],[0,-1,0,0],[0,0,0,1]]))
            lanes.append((temp,-1)) 

        for obj in objects: 
            if obj.type not in ["Ego","Car","Van","Cyclist"]:
                continue
            tf_matrix = np.array([[np.cos(obj.ry),-np.sin(obj.ry),0,obj.t[0]]
                        ,[np.sin(obj.ry),np.cos(obj.ry),0,obj.t[1]]
                        ,[0,0,1,obj.t[2]]])

            l = obj.l
            w = obj.w
            h = obj.h
            x_corners = [l / 2, l / 2, -l / 2, -l / 2
                        ,l / 2, l / 2 + 1.0, 0
                        ,l / 2, l / 2, -l / 2, -l / 2]
            z_corners = [h/2, h/2, h/2, h/2
                            , 0, 0, -h/2
                            , -h/2, -h/2, -h/2, -h/2]
            y_corners = [w / 2, -w / 2, -w / 2, w / 2
                        , 0, 0, 0                
                        , w / 2, -w / 2, -w / 2, w / 2]
            ones = [1,1,1,1,1,1,1,1,1,1,1]
            corners_3d = np.vstack([x_corners, y_corners, z_corners,ones])
            box3d_pts_3d_world = np.dot(tf_matrix[:3,:4],corners_3d).T

            pts_3d_extend = np.hstack((box3d_pts_3d_world[:,:3], np.ones((len(box3d_pts_3d_world), 1))))
            w2c = inverse_rigid_trans(c2w[i][:3,:4])
            pts_3d = np.dot(pts_3d_extend,np.transpose(w2c))
            pts_3d = pts_3d @ np.transpose(np.array([[0,0,1],[-1,0,0],[0,-1,0]]))
            boxes.append((pts_3d[:,:3],obj.type,obj.uid)) 
        lanes_all.append(lanes) 
        boxes_all.append(boxes)
    
    xmin,ymin = np.inf,np.inf 
    xmax,ymax = -np.inf,-np.inf 
    #xmin = np.min([np.min([box[:,0].min() for box,btype,uid in boxes]) for boxes in boxes_all])
    #xmax = np.max([np.max([box[:,0].max() for box,btype,uid in boxes]) for boxes in boxes_all])
    #ymin = np.min([np.min([box[:,1].min() for box,btype,uid in boxes]) for boxes in boxes_all])
    #ymax = np.max([np.max([box[:,1].max() for box,btype,uid in boxes]) for boxes in boxes_all])
    for boxes in boxes_all: 
        for box,btype,uid in boxes:
            xmin = min(xmin,box[:,0].min())
            xmax = max(xmax,box[:,0].max())
            ymin = min(ymin,box[:,1].min())
            ymax = max(ymax,box[:,1].max())
    #xmin = min(xmin,np.min([np.min([lane[:,0].min() for lane,lid in lanes]) for lanes in lanes_all]))
    #xmax = max(xmax,np.max([np.max([lane[:,0].max() for lane,lid in lanes]) for lanes in lanes_all]))
    #ymin = min(ymin,np.min([np.min([lane[:,1].min() for lane,lid in lanes]) for lanes in lanes_all]))
    #ymax = max(ymax,np.max([np.max([lane[:,1].max() for lane,lid in lanes]) for lanes in lanes_all]))
    for lanes in lanes_all: 
        for lane,lid in lanes: 
            xmin = min(xmin,lane[:,0].min())
            xmax = max(xmax,lane[:,0].max())
            ymin = min(ymin,lane[:,1].min())
            ymax = max(ymax,lane[:,1].max())
    #xmax = 2000

    bev_dir = os.path.join(save_dir,'BEV_try_topo2d')
    if not os.path.exists(bev_dir):
        os.mkdir(bev_dir)
    for (idx,boxes) in enumerate(tqdm(boxes_all)):
        fig = plotBEV(idx,boxes,(xmin,xmax,ymin,ymax),lanes_all[idx])
        save_file = os.path.join(bev_dir,'{:05d}.png'.format(idx))
        fig.savefig(save_file)
        plt.close()


if __name__=="__main__": 
    '''
       输出2个文件夹的图像(包含车道想和追踪目标bbx),bev_v输出bev视角图像,fov_w输出相机视角图像
       存储位置为存储目录下的BEV_try_topo2d和FOV_try_topo2d文件夹
    ''' 
    ## 输入变量包含4个,分别为：
    ## 轨迹文件
    ## 车道线文件
    ## 追踪文件
    ## 存储目录
    bev_v('/root/Codes/tracking/EagerMOT/data/1119_nj/ins_2024-09-13-09-29-14.csv'
        ,'/root/Codes/tracking/EagerMOT/data/1119_nj/track_id_world.json'
        ,'/root/Codes/tracking/EagerMOT/output_post.txt'
        ,'/root/Codes/tracking/EagerMOT/figures/1119_nj')
    ## 输入变量包含5个,分别为：
    ## 原始图像文件夹位置
    ## 车道线文件
    ## 轨迹文件
    ## 追踪文件
    ## 存储目录
    fov_w('/root/Codes/tracking/EagerMOT/data/origin'
         ,'/root/Codes/tracking/EagerMOT/data/1119_nj/track_id_world.json'
         ,'/root/Codes/tracking/EagerMOT/data/1119_nj/ins_2024-09-13-09-29-14.csv'
         ,'/root/Codes/tracking/EagerMOT/output_post.txt'
         ,'/root/Codes/tracking/EagerMOT/figures/1119_nj')
    